#include <Arduino.h>
#include "ui_manager.h"
#include <time.h>

// Declaration of communication function (located in comms_master.cpp)
extern void TaskMasterComms(void * pvParameters);

void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("--- MASTER UNIT STARTED ---");
    
    // 1. Initialize display and UI
    UI_Init();

    // 2. Start communication task
    // Running on Core 1 to avoid interfering with future WiFi (which runs on Core 0)
    xTaskCreatePinnedToCore(TaskMasterComms, "MasterComms", 4096, NULL, 1, NULL, 1);
    
    // Example: Update time periodically (you can use RTC or NTP later)
    // UI_UpdateTime(12, 30);
    // UI_UpdateDate("Jan 10");
    
    // Example: Update weather (connect to weather API later)
    // UI_UpdateWeather(22.5, "sunny");
}

void loop() {
    // Update time every second (simple example)
    static unsigned long last_update = 0;
    static int minutes = 0;
    static int hours = 12;
    
    if(millis() - last_update > 60000) { // Every minute
        last_update = millis();
        minutes++;
        if(minutes >= 60) {
            minutes = 0;
            hours++;
            if(hours >= 24) hours = 0;
        }
        UI_UpdateTime(hours, minutes);
    }
    
    // Update WiFi status every 5 seconds
    static unsigned long last_wifi_check = 0;
    if(millis() - last_wifi_check > 5000) {
        last_wifi_check = millis();
        UI_UpdateWiFiStatus();
    }
    
    // Fetch weather every 10 minutes
    static unsigned long last_weather_fetch = 0;
    if(millis() - last_weather_fetch > 600000) {  // 10 minutes
        last_weather_fetch = millis();
        fetchWeather();
    }
    
    // Check screensaver
    checkScreensaver();
    
    vTaskDelay(1000);
}